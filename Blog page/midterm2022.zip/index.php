<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="Description" content="Enter your description here"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Meme Midterm 2022</title>
    </head>
    <body>

    <header>
      <!-- Fixed navbar -->
      

      <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-primary">
      <div class="container">
        <a class="navbar-brand" href="#"><i class="fa fa-bomb mr-2" aria-hidden="true"></i>Meme Magic Midterm</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="memes.php">Memes</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php">Login</a>
            </li>
          </ul>
        </div>
        </div>
      </nav>
    </header>

    <!-- Begin page content -->
    <div class="jumbotron" style="background: url(images/bg2.jpg); background-size:cover;">
    <main role="main" class="container mt-4 py-3">
      <div class="p-5 bg-white">
      <h1 class="py-2"><i class="fa fa-book" aria-hidden="true"></i> Best Memes to Cringe to</h1>
      <p class="lead">Output the 12 memes using BS4 Cards (img/title/text). Link them their single memes using a get request with the meme ID.</p>
      </div>
      </main>
    </div>
      <hr>
    <div class="container py-4">
      <h3 class="font-weight-light">Recent Memes</h3>
      <hr>
      <div class="row">
        
      </div>
</div>

<footer class="footer bg-dark text-white py-5">
      <div class="container">
        <h3> <i class="fa fa-bomb" aria-hidden="true"></i> Meme Midterm<?php echo date("Y"); ?></h3>
      </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js"></script>
    </body>
</html>


