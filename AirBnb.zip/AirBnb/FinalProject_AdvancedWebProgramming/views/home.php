<?php
    include "views/inc/header.php";
?>

<h1>home</h1>

<?php
    include "views/inc/footer.php";
?>