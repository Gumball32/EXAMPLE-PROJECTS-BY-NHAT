Group AirBnb:
2059029 - Nguyen Hoang My
2059031 - Cao Minh Nhat
2059045 - Dinh Nguyet Tram
2059001 - Nguyen Khanh An

You can use this user if you like:
username: Nhat123
password: Nhat123

In this project, we were able to:
1. Edit profile for user (edit name, email, phone number)
2. Upload avatar for User
3. Upload image for Room
4. Filter search Room
5. Allow user to become a host (click on Register A Room)
6. Allow user to make reservation
7. Allow user to review a room if they have made a reservation before or else it’ll not work
8. Delete review if that user is the author of that comment
9. Delete room if that user is the author of that post 
10. Check if the room has already booked. If so, the user can not book that room
 	
AND OTHER FEATURES…

You can also see our prject on Github: https://github.com/Gumball32/FinalProject_AdvancedWebProgramming